<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col">
        <form action="https://digitalpelajar.bukaolshop.site/produk/judulproduk" method="GET" class="form-group">
            <div class="input-group mt-3 mb-3">
                
                <input type="text" name="catatan" class="form-control" placeholder="Masukan Nomor Hp">
                <a href="https://digitalpelajar.bukaolshop.site/ambil_kontak"> <button class="btn btn-secondary rounded-0"><i class="fa fa-address-book"></i></button> </a>
            </div>

            <select name="operator" id="operator" class="form-control">
                <option selected disabled>Pilih operator</option>
                <option value="362945">Tri</option>
                <option value="362947">Telkomsel</option>
                <option value="362949">Indosat</option>
                <option value="362951">XL</option>
                <option value="362952">Smartfren</option>
                <option value="362953">Axis</option>
            </select>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/MY STARTUP/web/tpid/resources/views/users/pulsa.blade.php ENDPATH**/ ?>